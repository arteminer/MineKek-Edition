Спасибо за то что скачали наш ресурспак! В будущем мы планируем его
активно развивать. Спасибо всем за поддержку, за идеи и т.д.

Хочу поблагодарить свою команду, а именно: Zanellle,SirMrCewa,FIuGa, MOURT1N, cizhi4ka, SayL1ks_, Milyan, Dravenitt,Rokakaka,drobi1lka,Patronio,Primal

Ждите обновлений.


###################################################################################

Thank you for downloading our resource pack! We plan to
actively develop it in the future. Thank you all for your support, ideas, etc.

I want to thank my team, namely: SirMrCewa,FIuGa, MOURT1N, cizhi4ka, SayL1ks_, Milyan, Dravenitt, Zanellle,Rokakaka,drobi1lka,Patronio,Primal

Wait for updates.